export const log = val => {
  console.log("------------------ custom log 12------------------");
  console.log(val);
  console.log("------------------------------------------------");
};
