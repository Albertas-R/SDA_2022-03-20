import { log } from "./helpers";

import "./styles.scss";

log("juozas");

let a = true;
let b = true;

a ||= b;
